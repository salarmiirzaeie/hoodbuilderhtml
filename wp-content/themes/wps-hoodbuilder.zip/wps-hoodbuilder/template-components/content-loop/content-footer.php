	<footer class="entry-footer">
		<?php //wpsbase_entry_footer(); ?>
	</footer><!-- .entry-footer -->